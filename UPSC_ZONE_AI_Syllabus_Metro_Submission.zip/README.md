# UPSC ZONE AI — "The Syllabus Metro"
### Official Submission for Web Home UI Designer Challenge

> **Concept Tagline:** *"Your UPSC journey, mapped."*  
> **Submission Type:** Complete Interactive Web Home UI (HTML5, Vanilla CSS3, Vanilla ES6 JavaScript)  
> **Target Audience:** UPSC CSE & State PSC Aspirants (Prelims, Mains, Interview stages)

---

## 🚇 1. Design Concept & Philosophy

The Civil Services Examination (CSE) is widely considered India's most demanding competitive exam. Aspirants often experience cognitive overload—a feeling of getting lost inside thousands of pages of static PDFs and syllabus notifications.

**"The Syllabus Metro"** transforms this daunting syllabus into an intuitive, elegant transit network:
- **Every stage is a transit line:**
  - **Line 1 — Prelims Express (Saffron `#F59E0B`):** High-speed, high-frequency objective question diagnostics and CSAT analytics.
  - **Line 2 — Mains Corridor (Sapphire `#38BDF8`):** Analytical depth, multi-dimensional answer writing, and instant rubric scoring.
  - **Line 3 — Personality Line (Teal `#0E9F8E`):** DAF keyword parsing and simulated board cross-examinations.
- **Every syllabus topic is a station:** As the aspirant progresses, the track draws itself and the metro glider moves along the active corridor.
- **Dholpur House Terminus:** The final station representing UPSC headquarters, reached with zero syllabus blindspots.

---

## 🎨 2. Design System & Typography

- **Colors:**
  - Base Concourse: Ink Navy (`#0F1B33`) with dark surface layers (`#080D1A`, `#13223F`, `#17294D`)
  - Accent / Paper: Paper Cream (`#F8F3E8`) for warm contrast
  - Transit Line 1 (Prelims): High-luminance Saffron (`#F59E0B`)
  - Transit Line 2 (Mains): Sapphire Blue (`#38BDF8`)
  - Transit Line 3 (Interview): Deep Emerald Teal (`#0E9F8E`)
- **Typography:**
  - Headings: **Fraunces** (Editorial serif with italic calligraphic accents)
  - Body & UI: **Inter** (Clean, modern sans-serif optimized for legibility)
  - Telemetry & Stations: **JetBrains Mono** (Transit codes, countdown clocks, metrics)
- **Visual Assets:**
  - 100% original inline SVG vector shapes, metro line paths, roundels, and CSS mockups.
  - Zero external bitmap images, zero copied templates, and zero political or official government emblems.

---

## 🧩 3. Key Sections Included

1. **Live Transit Telemetry Ticker & Sticky Header:** Real-time syllabus ticker, SVG roundel logo, and a *"You Are Here"* progress train indicator that glides along the navbar tracking document scroll depth.
2. **Hero Concourse:** Tagline *"Your UPSC journey, mapped."*, live ticking Prelims countdown chip (`SIGNAL CLEAR • 100% SYLLABUS MAPPED`), animated background metro lines, and quick station preview dock.
3. **The Syllabus Metro Map (Core Interactive Feature):**
   - **Desktop/Tablet:** Full 3-line SVG network diagram with curved tracks, station nodes, and glider train animation.
   - **Mobile (`<= 860px`):** Automatically converts to an authentic vertical transit timeline with branch-colored nodes.
   - **Station Inspection Modal:** Interactive modal with syllabus breakdown and CSS-drawn mock interfaces for all 6 stations (*AI Mocks*, *Current Affairs*, *Smart Notes*, *PYQ Matrix*, *Answer Writing Evaluator*, and *Interview Simulator*).
4. **Operational Telemetry (Stats Strip):** Real-time counters (1.84M+ questions, 42.5k aspirants, 312k mocks, 98.4% syllabus precision) animated with ease-out interpolation upon scrolling into view.
5. **The Arrivals Board (Social Proof):** Authentic railway terminal split-flap display board with flip mechanics, live station clock, and sample aspirational selection records.
6. **How It Works (3-Stage Commute):** *Board & Calibrate (Platform 1)* → *Practice En Route (High-Speed Line)* → *Arrive & Excel (Dholpur Terminus)*.
7. **Transit Fares & Passes:** Single Line Token, Complete Corridors Smart Card, and Annual Dholpur Pass.
8. **Metro Commuter Pass CTA Banner:** Embossed pass design with punch-card notches, magnetic stripe, and functional email pass issuance form.
9. **Station Exit Wayfinding Footer:** High-contrast directional sign (`WAY OUT ↗`), transit directory links, live IST clock, and transparent pedagogical disclosure.

---

## ♿ 4. Accessibility & Responsiveness

- **Zero Console Errors:** Clean, modular vanilla JavaScript.
- **Zero Horizontal Overflow:** Verified across desktop (`1440px`), tablet (`768px`), and mobile (`375px`).
- **Touch-First:** All mobile buttons and clickable targets have minimum touch dimensions of 44–48px.
- **Contrast & Motion:** Complies with WCAG AA contrast standards and includes `@media (prefers-reduced-motion: reduce)` fallbacks.

---

## 🚀 5. How to Run & View

1. **Local Preview:** Simply double-click `index.html` to open in any modern browser (Chrome, Edge, Firefox, Safari). No npm install, no build step required.
2. **Local HTTP Server (Optional):**
   ```bash
   python -m http.server 3000
   # Open http://localhost:3000 in your browser
   ```

---

*Authored with precision for the UPSC ZONE AI Web Home UI Designer Challenge.*
